package ec.edu.espoch.artefactopoo.modelo;

public class CalcularIntegrales {
    
    public String procedimiento(String funcion){
        String[] terminos = funcion.split(" ");

        String proc = "";

        for (String termino : terminos) {
            char v = termino.charAt(0);
            if (v == '+'){
                String nvTermino = termino.substring(1);
                proc+="+∫("+nvTermino+") dx ";
            } else if(termino.charAt(0)=='-'){
                String nvTermino = termino.substring(1);
                proc+="-∫("+nvTermino+") dx ";
            } else{
                proc+="∫("+termino+") dx ";
            }
        }
        return proc;
    }
    
    public static int calcularMCD(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    } 
    
    public String resolverIntegral(String funcion){
        String[] terminos = funcion.split(" ");

        String resultado = "";

        for (String termino : terminos) {
            int numerCoeficiente;
            int denomCoeficiente;
            int numerExponente = 0;
            int denomExponente = 0;

            boolean tieneX;

            if(termino.contains("x")){
                tieneX = true;
                String c = termino.substring(0, termino.indexOf("x"));
                if (c.isEmpty() || c.equals("+")) {
                    numerCoeficiente = 1;
                    denomCoeficiente = 1;  
                } else if (c.equals("-")) {
                    numerCoeficiente = -1;
                    denomCoeficiente = 1;
                } else {
                    if(c.contains("/")){
                        String[] partes = c.split("/");
                        numerCoeficiente = Integer.parseInt(partes[0]);
                        denomCoeficiente = Integer.parseInt(partes[1]); 
                    }else{
                        numerCoeficiente = Integer.parseInt(c);
                        denomCoeficiente = 1;
                    }
                }
                if (termino.contains("^")) {
                    String e = termino.substring(termino.indexOf("^") + 1);
                    if(e.contains("/")){
                        String[] partes = e.split("/");
                        numerExponente = Integer.parseInt(partes[0]);
                        denomExponente = Integer.parseInt(partes[1]); 
                    }else{
                        numerExponente = Integer.parseInt(e);
                        denomExponente = 1;
                    }
                } else {
                    numerExponente = 1;
                    denomExponente = 1;
                }  
            }else{
                tieneX = false;
                if(termino.contains("/")){
                    String[] partes = termino.split("/");
                    numerCoeficiente = Integer.parseInt(partes[0]);
                    denomCoeficiente = Integer.parseInt(partes[1]); 
                }else{
                    numerCoeficiente = Integer.parseInt(termino);
                    denomCoeficiente = 1;
                }
            }

            String resultadoParcial;

            int newNumCoeficiente;
            int newNumExponente;
            int newDenCoeficiente;
            int newDenExponente;
            if (tieneX) {
                newNumCoeficiente = numerCoeficiente * denomExponente;
                newNumExponente = numerExponente + denomExponente;
                newDenCoeficiente = denomCoeficiente * newNumExponente;
                newDenExponente = denomExponente;

                int mcdCoe = calcularMCD(newNumCoeficiente, newDenCoeficiente);
                newNumCoeficiente /= mcdCoe;
                newDenCoeficiente /= mcdCoe;

                int mcdExp = calcularMCD(newNumExponente, newDenExponente);
                newNumExponente /= mcdExp;
                newDenExponente /= mcdExp;

                newNumCoeficiente = (newDenCoeficiente < 0) ? -newNumCoeficiente : newNumCoeficiente*1;
                newDenCoeficiente = (newDenCoeficiente < 0) ? -newDenCoeficiente : newDenCoeficiente;
                newNumExponente = (newDenExponente < 0) ? -newNumExponente : newNumExponente;
                newDenExponente = (newDenExponente < 0) ? -newDenExponente : newDenExponente;

                String coeficienteParte = (newNumCoeficiente == 1) ? "" : (newNumCoeficiente == -1) ? "-" : newNumCoeficiente + "";
                String xParte = (newNumExponente == 1) ? "x" : "x^" + newNumExponente;

                if (newDenCoeficiente == 1) {
                    if(newDenExponente == 1){
                        resultadoParcial = coeficienteParte + xParte;
                    }else{
                        resultadoParcial = coeficienteParte + xParte + "/" + newDenExponente;

                    }
                } else {
                    if(newDenExponente == 1){
                        resultadoParcial = "(" + coeficienteParte + xParte + ")/" + newDenCoeficiente;
                    }else{
                        resultadoParcial = "(" + coeficienteParte + xParte + "/" + newDenExponente + ")/" + newDenCoeficiente;
                    }
                }
            }else{
                newNumCoeficiente = numerCoeficiente;
                resultadoParcial = (numerCoeficiente == 1 && denomCoeficiente == 1)? "x" : (numerCoeficiente == -1 && denomCoeficiente == 1 || numerCoeficiente == 1 && denomCoeficiente == -1)? "-x" : (numerCoeficiente != 1 && denomCoeficiente == 1)? numerCoeficiente + "x" : numerCoeficiente + "x/" + denomCoeficiente; 
            }
            if(newNumCoeficiente >0){
                resultado += "+" + resultadoParcial + "  ";   
            }else{
                String newResultadaTermino;
                if(resultadoParcial.contains("(")){
                    newResultadaTermino = resultadoParcial.substring(0, 1)+ resultadoParcial.substring(2);
                }else{
                    newResultadaTermino = resultadoParcial.substring(1);
                }
                resultado += "-" + newResultadaTermino + "  ";
            }
        }
        return resultado + " +C";      
    }
}
