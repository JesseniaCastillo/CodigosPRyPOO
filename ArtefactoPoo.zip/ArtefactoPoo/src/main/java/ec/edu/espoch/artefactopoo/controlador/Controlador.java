package ec.edu.espoch.artefactopoo.controlador;

import ec.edu.espoch.artefactopoo.modelo.CalcularIntegrales;
import ec.edu.espoch.artefactopoo.vista.Interfaz;

public class Controlador {
    private Interfaz vista;
    private CalcularIntegrales modelo;

    public Controlador(Interfaz vista) {
        this.vista = vista;
        modelo = new CalcularIntegrales();
    }
    
    public void accionBotonCal() {
        vista.setP1("∫(" + vista.getEntrada() + ")dx");

        vista.setP3(modelo.resolverIntegral(vista.getEntrada()));
        
        
        vista.setP2(modelo.procedimiento(vista.getEntrada()));
    }

    public void accionBotonBorr() {
        vista.eliminar();
    }
}
