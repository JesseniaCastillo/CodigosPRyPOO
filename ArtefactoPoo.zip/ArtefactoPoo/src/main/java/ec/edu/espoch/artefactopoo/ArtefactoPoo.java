package ec.edu.espoch.artefactopoo;

import ec.edu.espoch.artefactopoo.vista.Interfaz;

public class ArtefactoPoo {

    public static void main(String[] args) {
        Interfaz objInterfaz = new Interfaz();
        objInterfaz.setVisible(true);
        objInterfaz.setLocationRelativeTo(null);
        
    }
}
