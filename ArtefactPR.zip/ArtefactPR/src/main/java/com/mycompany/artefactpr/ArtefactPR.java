
package com.mycompany.artefactpr;

import ec.edu.espoch.artefactopr.vista.Interfaz;


public class ArtefactPR {

    public static void main(String[] args) {
        Interfaz objInterfaz = new Interfaz();
        objInterfaz.setVisible(true);
        objInterfaz.setLocationRelativeTo(null);
    }
}
